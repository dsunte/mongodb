#!/bin/bash
python ./test/sweetscomplete/entity/test_customer.py
python ./test/sweetscomplete/entity/test_product.py
python ./test/sweetscomplete/entity/test_purchase.py
