# sweetscomplete.entity.product.Product test

# tell python where to find module source code
import os,sys
sys.path.append(os.path.realpath("test"))

import unittest
from sweetscomplete.entity.product import Product

