#!/usr/bin/python

import datetime
today = datetime.datetime.today()
dateOfPurchase = today.strftime('%Y-%m-%d %H:%M:%S')
print(dateOfPurchase)
